The .streamlit folder contains the Streamlit configuration file, config.toml, that can be used to customize various configuration settings.

The config.toml file in here contains all the available settings with their default values. 
The only section I customized is the [theme] section at the bottom of the file.