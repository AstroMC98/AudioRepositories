The media folder is where the created audio files (audio.mp3, audio.wav) will be stored.

In this sample app the audio files will always be named audio.mp3 or audio.wav. The files will be overwritten every time a text-to-speech conversion is performed.