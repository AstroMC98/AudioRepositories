The static folder contains any static configuration files, images, CSS files, etc. 

#### css
The custom CSS file in this sample app does not do that much, apart from removing the streamlit branding. It contains some commented-out sections that can still serve as an example of how different style aspects of the Streamlit app could be customized.

#### img
The image folder contains the logo.png file, which is used as a logo at the top of this example Streamlit app. The same file is used as the page icon, too.
Replace the image file with your own or modify the Python constants in the main app.py file.
